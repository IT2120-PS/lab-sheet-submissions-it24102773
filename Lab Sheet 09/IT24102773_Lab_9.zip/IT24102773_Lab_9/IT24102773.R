setwd("C:\\Users\\tikka\\Desktop\\LABS\\ps\\IT24102633_Lab_9")

set.seed(123)   
bake_times <- rnorm(25, mean = 45, sd = 2)
bake_times

mean_b <- mean(bake_times)
sd_b <- sd(bake_times)

mean_b
sd_b

tres <- t.test(bake_times, mu = 46, alternative = "less")
tres

t_statistic <- tres$statistic
p_value <- tres$p.value
conf_interval <- tres$conf.int

t_statistic
p_value
conf_interval